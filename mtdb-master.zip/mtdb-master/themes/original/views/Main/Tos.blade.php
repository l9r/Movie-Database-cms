@extends('Main.Boilerplate')

@section('bodytag')
	<body id="privacy">
@stop

@section('content')

    <div class="container" id="content">
    	{{ trans('tos.tos') }}
    </div>

@stop


