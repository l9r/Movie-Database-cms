<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h3>{{{ trans('main.message from') . ', ' . $name . ' at ' . $email }}}</h3>
 
        <p>
       	  {{{ $comment }}}
        </p>

    </body>
</html>
