<?php

return array(

    'name'                       => 'Group Name',
	'group' 					 => 'Group',
    'permissions'                 => 'Group Permissions',
	't_permission'                 => 'Title Permissions',
	'p_permission'                 => 'People Permissions',
	'u_permission'                 => 'Users Permissions',
	's_permission'                 => 'Slides Permissions',
	'ac_permission'                 => 'Actions Permissions',
	'settings_permission'                 => 'Settings Permissions',
	'ad_permission'                 => 'Ads Permissions',
	'review_permission'                 => 'Reviews Permissions',
	'link_permission'                 => 'Links Permissions',

);