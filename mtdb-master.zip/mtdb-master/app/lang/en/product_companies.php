<?php

return array(
    'logo' => "Logo",
    'name' => "Name",
    'description' => "Description",
    'cover' => "Cover Photo",
);