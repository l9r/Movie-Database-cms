<?php
return array(
	
	'stripe' => [
		'secret'    => 'sk_test_fAxrCWf2BH0GtuRPXoUnkHep'
	]

);