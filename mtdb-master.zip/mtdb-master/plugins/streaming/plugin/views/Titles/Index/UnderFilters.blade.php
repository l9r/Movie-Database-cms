<div class="checkbox">
	<label>
  		<input type="checkbox" data-bind="checked: params.availToStream">
  		{{ trans('stream::main.onlyAvailToStream') }}
	</label>
</div>