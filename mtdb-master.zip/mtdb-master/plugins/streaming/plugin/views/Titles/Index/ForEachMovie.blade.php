<!-- ko if: link && link.length > 0 -->
	<div class="status">{{ trans('stream::main.availToStream') }}</div>
<!-- /ko  -->